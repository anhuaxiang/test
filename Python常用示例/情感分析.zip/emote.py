# -*- coding:utf-8 -*-
import jieba
import numpy
import xlrd
import math


def get_key_mood_map(name):
    data = xlrd.open_workbook(name)
    key_mood_map = {}
    for sheet in [0]:
        table = data.sheets()[sheet]
        for nrow in range(0, table.nrows):
            if name == "feel.xlsx":
                key_mood_map[table.row_values(nrow)[0]] = \
                    {
                        "_class": table.row_values(nrow)[1],
                        "strength": table.row_values(nrow)[2]
                    }
            else:
                key_mood_map[table.row_values(nrow)[0]] = \
                    {
                        "_class": ' ',
                        "strength": ' '
                    }
    return key_mood_map
#情感分析类



def start(j, key_mood_map, key_not_map, key_degree_map):
    jieba.load_userdict('new.txt')
    j=jieba.cut(j)
    article_mood = {
        "happy": 0, "good": 0, "anger": 0, "sorrow": 0,
        "fear": 0, "evil": 0, "surprise": 0, "all":0
    }
    mood_map = {
        u"乐": ('PA', 'PE'),
        u"好": ('PD', 'PH', 'PG', 'PB', 'PK'),
        u"怒": ('NA'),
        u"哀": ('NB', 'NJ', 'NH', 'PF'),
        u"惧": ('NI', 'NC', 'NG'),
        u"恶": ('NE', 'ND', 'NN', 'NK', 'NL'),
        u"惊": ('PC'),
    }
    flag = 1
    no = 0
    for key in j:
        any = 0
        p1 = 0
        p2 = 0
        p3 = 0
        p4 = 0
        p5 = 0
        p6 = 0
        p7 = 0
        if key_degree_map.get(key):
            if no == 1:
                flag = flag * (-1) * 0.5
                no = 0
            else:
                flag = flag * 2
                no = 0
        if key_not_map.get(key):
            flag = (-1) * flag
            no = 1
        if key_mood_map.get(key):
            any += 1
            no = 0
            mood_strength = key_mood_map.get(key)
            if mood_strength['_class'] in mood_map[u'乐']:
                article_mood['happy'] = article_mood['happy'] + mood_strength['strength'] * flag
                p1 += 1
            if mood_strength['_class'] in mood_map[u'好']:
                article_mood['good'] = article_mood['good'] + mood_strength['strength'] * flag
                p2 += 1
            if mood_strength['_class'] in mood_map[u'怒']:
                article_mood['anger'] = article_mood['anger'] + mood_strength['strength'] * flag
                p3 += 1
            if mood_strength['_class'] in mood_map[u'哀']:
                article_mood['sorrow'] = article_mood['sorrow'] + mood_strength['strength'] * flag
                p4 += 1
            if mood_strength['_class'] in mood_map[u'惧']:
                article_mood['fear'] = article_mood['fear'] + mood_strength['strength'] * flag
                p5 += 1
            if mood_strength['_class'] in mood_map[u'恶']:
                article_mood['evil'] = article_mood['evil'] + mood_strength['strength'] * flag
                p6 += 1
            if mood_strength['_class'] in mood_map[u'惊']:
                article_mood['surprise'] = article_mood['surprise'] + mood_strength['strength'] * flag
                p7 += 1
            flag = 1
    list_n=[p1, p2, p3, p4, p5, p6, p7]
    narray = numpy.array(list_n)
    sum1 = narray.sum()
    narray2 = narray * narray
    sum2 = narray2.sum()
    mean = sum1 / 7
    var = sum2 / 7 - mean ** 2
    p = []
    for x in list_n:
        u = (x - mean) / var
        x = abs(u) / math.sqrt(2)
        T = (0.0705230784, 0.0422820123, 0.0092705272,
                0.0001520143, 0.0002765672, 0.0000430638)
        E = 1 - pow((1 + sum([a * pow(x, (i + 1))
                                for i, a in enumerate(T)])), -16)
        p.append(0.5 - 0.5 * E if u < 0 else 0.5 + 0.5 * E)

    cps = 2 * article_mood['happy'] * p[0] + 2 * article_mood['good'] * p[1] - 3 * article_mood['anger'] * p[2] - article_mood[
            'sorrow'] * p[3] - 2 * article_mood['fear'] * p[4] - 3 * article_mood['evil'] * p[5] - article_mood['surprise'] * p[6]
    article_mood['all']=cps
    return article_mood

def analysis(text):
    key_mood_map = get_key_mood_map("feel.xlsx")
    key_not_map = get_key_mood_map("not.xlsx")
    key_degree_map = get_key_mood_map("degree.xlsx")
    emote = start(text, key_mood_map, key_not_map, key_degree_map)
    return emote
